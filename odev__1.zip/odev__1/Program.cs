﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev__1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            {
                // Kişiler oluşturuluyor
                Person person1 = new Person//araç sahibinin bilgileri
                {
                    Adi = "Hatice",
                    Soyadi = "SAZAK",
                    DogumYili = 1990,
                    Tckn = "12345678900" 
                };

                Person person2 = new Person//eski sahip
                {
                    Adi = "ali",
                    Soyadi = "YILDIZ",
                };
                Person person3 = new Person//eski sahip
                {
                    Adi = "Sema",
                    Soyadi = "KÖK",
                };
                Person person4= new Person//eski sahip
                {
                    Adi = "Uğur",
                    Soyadi = "KARA",
                };
                Person person5 = new Person//eski sahip
                {
                    Adi = "Melisa",
                    Soyadi = "ZAFER",
                };

                // Araç listesini oluşturuyorum
                List<Arac> araclar = new List<Arac>
        {
            new Arac//birinci aracın bilgileri
            {
                ŞaseNumarası = "ABC123DEF456",
                Model = "E92",
                Yıl = 2022,
                Marka = "BMW",
                EdinmeTarihi = DateTime.Now,
                EdinmeFiyati= 25000.00m,
                OncekiSahibi = person2//önceki sahibi buraya atadım
            },
            new Arac
            {
                ŞaseNumarası = "XYZ789UVW456",
                Model = "SUV",
                Yıl = 2021,
                Marka = "FORD",
                EdinmeTarihi = DateTime.Now.AddDays(-365), // Bir yıl önce alındı
                EdinmeFiyati = 30000.00m,
                OncekiSahibi = person3
            },
            new Arac
            {
                ŞaseNumarası = "PQR456LMN789",
                Model = "clio",
                Yıl = 2019,
                Marka = "RENAULT",
                EdinmeTarihi = DateTime.Now.AddDays(-730), // İki yıl önce alındı
                EdinmeFiyati = 20000.00m,
                OncekiSahibi = person4
            },
            new Arac
            {
                ŞaseNumarası = "JKL456MNO123",
                Model = "a3 cabrio",
                Yıl = 2018,
                Marka = "AUDİ",
                EdinmeTarihi = DateTime.Now.AddDays(-1095), // Üç yıl önce alındı
                EdinmeFiyati = 40000.00m,
                OncekiSahibi = person5
            }
        };

                // Araçları kişilere bağla
                person1.Arac.AddRange(araclar.GetRange(0, 2));
                person2.Arac.AddRange(araclar.GetRange(2, 2));

                // Kişilerin araçlarını listele
                Console.WriteLine($"Kişi Bilgileri: {person1.Adi} {person1.Soyadi}");
                Console.WriteLine("Araçlar:");
                foreach (var Arac in person1.Arac)
                {
                    Console.WriteLine($"Şasi Numarası: {Arac.ŞaseNumarası}");
                    Console.WriteLine($"Model: {Arac.Model}");
                    Console.WriteLine($"Yıl: {Arac.Yıl}");
                    Console.WriteLine($"Edinme Tarihi: {Arac.EdinmeTarihi}");
                    Console.WriteLine($"Önceki Sahibi: {Arac.OncekiSahibi.Adi} {Arac.OncekiSahibi.Soyadi}");
                    Console.WriteLine();
                }

                Console.WriteLine($"Kişi Bilgileri: {person2.Adi} {person2.Soyadi}");
                Console.WriteLine("Araçlar:");
                foreach (var Arac in person2.Arac)
                {
                    Console.WriteLine($"Şasi Numarası: {Arac.ŞaseNumarası}");
                    Console.WriteLine($"Model: {Arac.Model}");
                    Console.WriteLine($"Yıl: {Arac.Yıl}");
                    Console.WriteLine($"Edinme Tarihi: {Arac.EdinmeTarihi}");
                    Console.WriteLine($"Önceki Sahibi: {Arac.OncekiSahibi.Adi} {Arac.OncekiSahibi.Soyadi}");
                    Console.WriteLine();
                }

                Console.ReadLine();
            }
        }

        class Person//kişi bilgileri
        {
            public string Adi;
            public string Soyadi;
            public int DogumYili;//gixli bilgi
            public string Tckn;// Gizli bilgi
            public List<Arac> Arac  = new List<Arac>();
        }

        class Arac//arac bilgileri
        {
            public string ŞaseNumarası;
            public string Model;
            public int Yıl;
            public string Marka;
            public DateTime EdinmeTarihi;
            public decimal EdinmeFiyati;
            public Person OncekiSahibi;
        }


    }
}

